#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
int main()
{
   int n; char ch; 
   fflush(stdin);
   printf("Input integer n = ");
   scanf("%d %c",&n,&ch);
   fflush(stdin);
   if(ch==0) // Enter a
     printf("Incorrect input, the first input must be a number!\n");
   if(isalpha(ch))  // Enter 12a
	 {printf("Trailing character\n");    
      printf("n = %d\n",n);	
      printf("ch = %c\n",ch);}
    else
	  printf("Incorrect input, The second input must be a character!\n");		 	
 return(0);
}
