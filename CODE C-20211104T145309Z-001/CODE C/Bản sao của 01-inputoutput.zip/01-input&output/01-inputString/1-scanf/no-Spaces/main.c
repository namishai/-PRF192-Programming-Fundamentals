#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
//===================================
int main()
  { char str[200]; 
    system("CLS");
    printf("Enter the first string : ");
    scanf("%s",str);
    printf("The string entered is:  %s\n", str);
    fflush(stdin);
    printf("Enter the second string : ");
    gets(str);
    printf("The string entered is:  %s\n", str);
    return 0;
  }
